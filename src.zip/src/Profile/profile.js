import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { useState, useEffect } from "react"
// import './index.css'
import { profileData, profileUpdate } from "../config/firebase";
import { getAuth, onAuthStateChanged} from "firebase/auth";
import { useNavigate } from "react-router-dom"



export function Profile() {
    const [image, setImage] = useState([])
    const [img, setImg] = useState([])
    const [currentUser, setCurrentUser] = useState([])
    const [found, setFound] = useState([])
    // const [user, setUser] = useState([])
    // const [pdata, setpData] = useState
    const navigate = useNavigate()

    useEffect(() => {
        const auth = getAuth()
        onAuthStateChanged(auth, (user) => {
            if (user) {
                // console.log("user " ,user)
                const uid = user
                setCurrentUser(uid.email)
            } else {
                setCurrentUser(null)
            }
        });
    }, [])


    useEffect(() => {
        fetchData()

        async function fetchData() {
            try {
                const pdata = await profileData()
                console.log('Pdata', pdata)
                const foundItem = pdata.filter((res) => res.email === currentUser)
                setFound(foundItem)
                console.log("foundItem", foundItem)
                // if(foundItem){
                //     console.log("element Found" , foundItem)
                //     // setUserData(foundItem)
                //     if(found && found[0]){
                //         setImage(found[0].image)
                //     }
                //     else{
                //         setFound(null)
                //     }
                // } else{
                //     console.log("element Not Found")
                //     setImage(null)
                // } 
            } catch (e) {
                alert(e.message)
            }
        }
    }, [currentUser])


    async function saveChanges(){
        await profileUpdate(found , img)
        navigate('/')
    }

    if (!found.length) {
        return (
            <div>
                <p>Loading...</p>
            </div>
        )
    }
    return (
        <div>
            <Navbar />

            <div className="form-container">
    <div className="form-content">
        <div className="form-section">
            <h4>Edit Profile</h4>
        </div>
        <hr />
        <div className="form-section">
            <h5>Profile Photo</h5>
        </div>
        <div className="form-section image-upload">
            {currentUser ? <img src={found[0].image} />
                : <img src="https://www.olx.com.pk/assets/iconProfilePicture.7975761176487dc62e25536d9a36a61d.png" />
            }
            <div>
                <label>Upload Photo</label>
                <input type="file" onChange={(e) => setImg(e.target.files[0])}></input>
                <p>JPG, JPEG, PNG Min: 400px, Max: 1024px</p>
            </div>
        </div>
        <hr />
        <div className="form-section">
            <label>Name</label> <br />
            <input value={found ? `${found[0].fullName}` : ''} type="text"></input>
        </div>
        <div className="form-section">
            <label>Age</label> <br />
            <input value={found ? `${found[0].age}` : ''} type="text"></input>
        </div>
        <div className="form-section">
            <label>Email</label> <br />
            <input value={found ? `${found[0].email}` : ''} type="text"></input>
        </div>
        <div className="form-section">
            <textarea placeholder="About me (optional)"></textarea>
        </div>
        <div className="form-section">
            <button onClick={saveChanges} className="save-btn">Save Changes</button>
        </div>
    </div>
</div>


            <Footer />
        </div>

    )
}