import { login } from '../config/firebase'
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import "./Login.css";
// import Register from '../Register';
function Login() {

  const navigate = useNavigate();

  const [email, setEmail] = useState();
  const [password, setPassword] = useState();


  const signin = async () => {
    try {
      await login({ email, password, });
      navigate("/")
    }
    catch (e) {
      alert(e.message)
    }
  }
  return (
    <div className='Mainn-div'>
      <div className="login-container">
        <h1 className="login-title">Login</h1>
        <br />
        <input
          className="login-input"
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)}
        />
        <br />
        <input
          className="login-input"
          type="password"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)}
        />
        <br />
        <button className="login-button" onClick={signin}>
          Login
        </button>



        <p className="no-account-text">
          Don't you have an account?
          <span className="click-here" onClick={() => navigate("/register")}>
            Click here
          </span>
        </p>
      </div>
    </div>
  );

}
export default Login;



