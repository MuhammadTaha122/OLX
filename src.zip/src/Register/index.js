import { register } from "../config/firebase"
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import './Register.css'
function Register() {

    const navigate = useNavigate();
    const [fullname, setFullname] = useState()
    const [age, setAge] = useState();
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();


    const signup = async () => {
        try {
            await register({ email, password, age, fullname })
            navigate("/Login")
        }
        catch (e) {
            alert(e.message)
        }
    }
    {
        console.log(email)
        console.log(password)
    }
    return (
        <div className="signup-container">
            <h1 className="signup-title">Sign Up</h1>
            <input
                className="signup-input"
                placeholder="Fullname"
                onChange={(e) => setFullname(e.target.value)}
            />
            <br />
            <input
                className="signup-input"
                placeholder="Age"
                onChange={(e) => setAge(e.target.value)}
            />
            <br />
            <input
                className="signup-input"
                placeholder="Email"
                onChange={(e) => setEmail(e.target.value)}
            />
            <br />
            <input
                className="signup-input"
                type="password"
                placeholder="Password"
                onChange={(e) => setPassword(e.target.value)}
            />
            <br />
            <button className="signup-button" onClick={signup}>
                Sign Up
            </button>

            <p className="login-link">
                Already have an account?
                <span className="login-link-text" onClick={() => navigate("/login")}> </span>
                <span className="login-link-text" onClick={() => navigate("/login")}>Login</span>

            </p>
        </div >
    );

}
export default Register;



