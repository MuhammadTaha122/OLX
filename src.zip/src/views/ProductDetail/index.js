import { useParams } from "react-router-dom";
import React, { useEffect, useState } from "react";
import { Fade } from "react-slideshow-image";
import "./index.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faShareNodes } from "@fortawesome/free-solid-svg-icons";
import { getDoc, getFirestore, doc } from "firebase/firestore";
import { useNavigate } from "react-router-dom";

function ProductDetail() {
  const [productData, setProductData] = useState();
  const [loading, setLoading] = useState(true);
  let { id } = useParams();
  const navigate = useNavigate();
  console.log("ProductDetailId-------------", id);
  const db = getFirestore();
  const properties = {


  };

  useEffect(() => {
    getSingleProduct();
  }, []);

  const getSingleProduct = async () => {
    try {
      const docRef = doc(db, "userInfo", id);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        setProductData(docSnap.data());
        console.log("Document data:", docSnap.data());
      } else {
        console.log("No such document!");
      }
    } catch (error) {
      console.log(error);
    } finally {
      // Set loading to false once data is fetched
      setLoading(false);
    }
  };

  return (
    <>
      {loading ? (
        <div className="loading-container">
          <img
            src="/cartoon-snail-loading-loading-gif-animation_2734139.png!bw700"
            alt="Loading..."
            style={{ width: "200px", height: "200px" }}
          />
        </div>
      ) : (
        <>
          <div class="container">
            <div class="row gy-3 gx-4 mt-5">
              <div class="col-12 col-md-8 img-container">
                {/* Render the image directly */}
                {productData && productData ? (
                  <div key={1}>
                    <img
                      style={{
                        width: "65%",
                        height: "500px",
                        borderRadius: "5px",
                      }}
                      src={productData.url}
                    />
                  </div>
                ) : ""}
              </div>

              <div class="col-12 col-md-4">
                <p>{/* Your additional content here */}</p>
              </div>
            </div>

            <div class="row gy-1 gx-4 mt-5">
              <div class="col-12 col-md-8 content-container">
                {/* Top Section */}
                <div className="top-section">
                  <div className="top-section-price">
                    <h1>{`Rs ${productData?.price}`}</h1>
                  </div>
                </div>

                {/* Middle Section */}
                <div className="top-section">
                  <div className="top-section-price">
                    <h5>{`${productData.title}`}</h5>
                  </div>
                </div>

                {/* Bottom Section */}
                <div className="top-section bottom">
                  <div className="top-section-price">
                    <h6>
                      <FontAwesomeIcon
                        icon={faShareNodes}
                        style={{ marginRight: "10px" }}
                      />
                      {`${productData.description}`}
                    </h6>
                  </div>

                  <div className="top-section-icons">
                    <div className="">
                      <p>Active 6 Days ago</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
}

export default ProductDetail;
