
import Card from "../../components/Card";
import { useEffect, useState } from "react";
import Navbar from "../../components/Navbar";
import Categories from "../Categories";
import Footer from "../../components/Footer";

import { auth, getAds } from "../../config/firebase";
import { useNavigate } from 'react-router-dom';  // Import useNavigate

function Dashboard() {
  const [products, setProducts] = useState([]);
  const navigate = useNavigate();  // Define navigate

 

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    const ads = await getAds();
    console.log("ads in component", ads);
    setProducts(ads);
  };
console.log("product:",products)
  return (
    <>

    

      <Navbar />

      <Categories />

      {
        products && products.length > 0 ? (
          <>
            <div className="container-fluid">
              <div className="row gy-3 gx-4 mt-5">
                <h4 style={{ textAlign: "left" }}>Products</h4>

                {products.map((product) => {
                  const { title, description, url, price, id } = product;
                  return (
                    <div className="col-12 col-md-3" key={id}>
                      <Card
                        id={id}
                        title={title}
                        description={description}
                        thumbnail={url}
                        price={price}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        ) : null
      }
      <Footer />
    </>
  );
}

export default Dashboard;
