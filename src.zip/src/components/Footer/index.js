import "./index.css";

function Footer() {
  return (
    <div className="div">

      <div className="row mt-5 footer ">
        {/* Grid column */}
        <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 className="text-uppercase list1"> <b>Popular Categories</b></h5>
          <ul className="list-unstyled mb-0 list1 ">
            <li>
              <a className="text-body">Cars</a>
            </li>
            <li>
              <a className="text-body">Flats For Rent</a>
            </li>
            <li>
              <a className="text-body" >Mobile Phones</a>
            </li>
            <li>
              <a className="text-body" >Jobs</a>
            </li>
          </ul>
        </div>
        <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 className="text-uppercase list1 "><b>Trending Searches</b></h5>
          <ul className="list-unstyled mb-0 list1 ">
            <li>
              <a className="text-body" href="#!">Bikes</a>
            </li>
            <li>
              <a className="text-body" href="#!">Watches</a>
            </li>
            <li>
              <a className="text-body" href="#!">Books</a>
            </li>
            <li>
              <a className="text-body" href="#!">Dogs</a>
            </li>
          </ul>
        </div>
        <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 className="text-uppercase list1 "><b>ABOUT US</b></h5>
          <ul className="list-unstyled mb-0 list1 ">
            <li>
              <a className="text-body" href="#!">About Dubizzle Group</a>
            </li>
            <li>
              <a className="text-body" href="#!">OLX Blog</a>
            </li>
            <li>
              <a className="text-body" href="#!">Contact Us</a>
            </li>
            <li>
              <a className="text-body" href="#!">Olx For Businessess</a>
            </li>
          </ul>
        </div>
        <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 className="text-uppercase list1 "><b>OLX</b></h5>
          <ul className="list-unstyled mb-0 list1 ">
            <li>
              <a className="text-body" href="#!">Help</a>
            </li>
            <li>
              <a className="text-body" href="#!">Site Map</a>
            </li>
            <li>
              <a className="text-body" href="#!">Terms Of Use</a>
            </li>
            <li>
              <a className="text-body" href="#!">Privacy Policy</a>
            </li>
          </ul>
        </div>
      </div>
      <div className="text-center p-3  f">
        <span className="ab">Free classifieds in Pakistan</span>
        <a className="text-reset fw " href="https://mdbootstrap.com/">. © 2006-2024 OLX</a>
      </div>
    </div>
  );
}

export default Footer;
