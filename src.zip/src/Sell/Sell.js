import { useNavigate } from "react-router-dom";
import "./sell.css";
import { useState, useEffect } from "react";
import { sell } from "../config/firebase";
import { getAuth } from "firebase/auth";

function Sell() {
  const navigate = useNavigate();
  const auth = getAuth();
  const [brand, setBrand] = useState("");
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [image, SetImage] = useState("");

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      // Show an alert if the user is not authenticated
      if (!user) {
        alert("Please login first.");
        navigate("/"); // You can choose to navigate to a different page after the alert
      }
    });

    return () => {
      // Unsubscribe from the onAuthStateChanged event when the component unmounts
      unsubscribe();
    };
  }, [auth, navigate]);

  const add = async () => {
    console.log('image', image);
    await sell({ brand, title, price, image });
    navigate('/');
    setBrand('');
    setTitle('');
    SetImage('');
  };

  return (
    <form className="sell-form" action="#">
      <div className="input-box">
        <h1>Post An Ad</h1>
        <input
          className="brand-input"
          type="text"
          placeholder="Enter brand name"
          value={brand}
          onChange={(e) => setBrand(e.target.value)}
        />
      </div>
      <div className="input-box">
        <input
          className="title-input"
          type="text"
          placeholder="Enter Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </div>

      <div className="input-box">
        <input
          className="price-input"
          type="text"
          placeholder="Enter Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
      </div>
      <div className="input-box">
        <input
          className="price-input"
          type="file"
          onChange={(e) => SetImage(e.target.files[0])}
        />
      </div>
      <div className="agreement-box">
        <input className="agreement-checkbox" type="checkbox" />
        <h6 className="agreement-text">I Accept All Terms And Policies</h6>
      </div>

      <div className="input-box-button">
        <input
          className="register-button"
          type="button"
          value="Register Now"
          onClick={add}
        />
      </div>
    </form>
  );
}

export default Sell;
