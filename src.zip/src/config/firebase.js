import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from "firebase/auth";
import { getFirestore, collection, addDoc, getDocs } from "firebase/firestore";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";

import { doc, deleteDoc } from "firebase/firestore";


const firebaseConfig = {
    apiKey: "AIzaSyCBMHgpIkrcKszJLj18RApBl5PKVq14yCo",
    authDomain: "olx-ba038.firebaseapp.com",
    projectId: "olx-ba038",
    storageBucket: "olx-ba038.appspot.com",
    messagingSenderId: "305940828093",
    appId: "1:305940828093:web:b879734d0ba3ed48acccd4"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

export async function register(userInfo) {

    const { email, password, age, fullname } = userInfo
    await createUserWithEmailAndPassword(auth, email, password)
    await addDoc(collection(db, "users"), {
        fullname,
        age,
        email,
    })
    alert("Successfully Registered !")
}



export async function login(userinfo) {


    const { email, password } = userinfo;
    await signInWithEmailAndPassword(auth, email, password);
    alert("Logged In Successfully");
}




export async function logout(userinfo) {
    try {
        await logout(auth);
        alert("Sign-out successful.");

    } catch (error) {
        // An error happened.
        console.error(error);
    }
}

export async function sell(userInfo) {
    try {
        const { brand, title, category, price, image } = userInfo;
        console.log("brand", brand)
        console.log("price", price)
        console.log("tite", title)

        const storageRef = ref(storage, `ads/${image.name}`);
        await uploadBytes(storageRef, image);
        const url = await getDownloadURL(storageRef);
        await addDoc(collection(db, "userInfo"), {
            brand, title, price, url
        })
        alert(" Ad Successfully Posted!")
    }
    catch (e) {
        alert(e.message);
    }

}




export async function getAds() {
    const querySnapshot = await getDocs(collection(db, "userInfo"));
    const ads = []
    querySnapshot.forEach((doc) => {
        const ad = doc.data()
        ad.id = doc.id
        ads.push(ad)

    });
    return ads
}
export const profileData = async () => {
    const postAds = []
    const querySnapshot = await getDocs(collection(db, "users"));
    querySnapshot.forEach((doc) => {
        const dat = doc.data()
        dat.id = doc.id
        postAds.push(dat)
    });
    return postAds
}

export async function profileUpdate(currentUserInfo, img) {
    console.log("e:", currentUserInfo)
    console.log("img:", img)
    const userData = currentUserInfo[0]
    try {

        const storageRef = ref(storage, `usersprofile/${img.name}`);
        await uploadBytes(storageRef, img);
        const Url = await getDownloadURL(storageRef)
        console.log(Url)
        await addDoc(collection(db, "users"), {
            // fullName:userData.fullName,
            age: userData.age,
            email: userData.email,
            image: Url,

        });
        const ver = await deleteDoc(doc(db, "users" ,userData.id))
        console.log(ver)
        alert("Update Changes (:")
        

    } catch (e) {
        alert(e.message)

    }




}