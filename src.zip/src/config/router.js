import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Dashboard from "../views/Dashboard";
import ProductDetail from "../views/ProductDetail";
import Login from "../Login";
import Register from "../Register";
import Sell from "../Sell/Sell"
import { Profile } from "../Profile/profile";
import { logout } from "./firebase";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Dashboard />,
  },
  {
    path: "/profile",
    element: <Profile />,
  },


  {
    path: "/productDetail/:id",
    element: <ProductDetail />,
  },


  {
    path: "/login",
    element: <Login />,
  },


  {
    path: "/Register", 
    element: <Register />,
  },

  {
    path: "/sell",
    element: <Sell />,
  },

]);

function Router() {
  return <RouterProvider router={router} />;
}

export default Router;


